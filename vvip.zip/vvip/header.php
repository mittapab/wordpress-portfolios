<!doctype html>
<html <?php language_attributes(); ?>>

<head>
     <title><?php wp_title('-', true, 'right'); ?><?php bloginfo('name'); ?></title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Demo">
      
   <?php  wp_head(); ?>
  
</head>

<body class="custom-background">
    <!-- Navbar -->
    <div class="container-fluid navbarmain">
        <button class="btn shadow-none fs-1 text-white py-0 px-1 d-block d-md-none" type="button"
            data-bs-toggle="offcanvas" data-bs-target="#offcanvasTop" aria-controls="offcanvasTop"> <i
                class="bi bi-list"></i>
        </button>

        <div class="lightning">
            <img src="<?php echo get_theme_file_uri('/public/img/ln01.png'); ?>" class="img-fluid" alt="logo">
        </div>

        <a href="#" class="">
            <img src="<?php echo get_theme_file_uri('/public/img/logo.png');?>" class="img-logo-desktop" alt="logo">
        </a>

        <div class="menu-mobile offcanvas offcanvas-top" tabindex="-1" id="offcanvasTop"
            aria-labelledby="offcanvasTopLabel">
            <div class="offcanvas-body">
                <div class="button-close-menu-mobile">
                    <button class="btn shadow-none fs-1 text-white py-0 px-1" type="button" data-bs-dismiss="offcanvas">
                        <i class="bi bi-x-lg"></i>
                    </button>
                </div>

                <div class="card-menu-mobile container-fluid">
                    <div class="row row-cols-3 g-3">
                        <div class="col">
                            <a href="<?php  echo esc_url(site_url('/โปรโมชั่น'));   ?>" class="nav-link card-menu-mobile-item">
                                <img src="<?php echo get_theme_file_uri('/public/img/icon/download-1.png');?>" class="icon-menu" alt="icon-menu">
                                <div class="p-1"><?php echo esc_html('โปรโมชั่น');?></div>
                            </a>
                        </div>
                        <div class="col">
                            <a href="<?php  echo esc_url(site_url('/บทความ'));   ?>" class="nav-link card-menu-mobile-item">
                                <img src="<?php echo get_theme_file_uri('/public/img/icon/menu-hot-ic.png');?>" class="icon-menu" alt="icon-menu">
                                <div class="p-1"><?php echo esc_html('บทความ');?></div>
                            </a>
                        </div>
                        <div class="col">
                            <a href="<?php  echo esc_url(site_url('/กิจกรรม'));   ?>" class="nav-link card-menu-mobile-item">
                                <img src="<?php echo get_theme_file_uri('/public/img/icon/calender02.png');?>" class="icon-menu" alt="icon-menu">
                                <div class="p-1"><?php echo esc_html('กิจกรรม');?></div>
                            </a>
                        </div>
                        <div class="col">
                            <a href="<?php  echo esc_url(site_url('/Line'));   ?>" class="nav-link card-menu-mobile-item">
                                <img src="<?php echo get_theme_file_uri('/public/img/icon/line.png');?>" class="icon-menu" alt="icon-menu">
                                <div class="p-1"><?php echo esc_html('Line');?></div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="menu-desktop">
            <div class="d-none d-md-block">
                <ul class="menu-content">
                    <li class="menu-item">
                        <a href="<?php  echo esc_url(site_url('/โปรโมชั่น'));   ?>" class="nav-link">
                            <div class="menu-item-list">
                                <img src="<?php echo get_theme_file_uri('/public/img/icon/download-1.png');?>" class="icon-menu" alt="icon-menu">
                                <?php echo esc_html('โปรโมชั่น');?>
                            </div>
                        </a>
                    </li>
                    <li class="menu-item">
                        <a href="<?php  echo esc_url(site_url('/บทความ'));   ?>" class="nav-link">
                            <div class="menu-item-list">
                                <img src="<?php echo get_theme_file_uri('/public/img/icon/menu-hot-ic.png');?>" class="icon-menu" alt="icon-menu">
                                <?php echo esc_html('บทความ');?>
                            </div>
                        </a>
                    </li>
                    <li class="menu-item">
                        <a href="<?php  echo esc_url(site_url('/กิจกรรม'));   ?>" class="nav-link">
                            <div class="menu-item-list">
                                <img src="<?php echo get_theme_file_uri('/public/img/icon/calender02.png');?>" class="icon-menu" alt="icon-menu">
                                <?php echo esc_html('กิจกรรม');?>
                            </div>
                        </a>
                    </li>
                    <li class="menu-item">
                        <a href="<?php  echo esc_url(site_url('/Line'));   ?>" class="nav-link">
                            <div class="menu-item-list">
                                <img src="<?php echo get_theme_file_uri('/public/img/icon/line.png');?>" class="icon-menu" alt="icon-menu">
                                <?php echo esc_html('Line');?>
                            </div>
                        </a>
                    </li>
                </ul>
            </div>

            <div class="loginregishead">
                <a href="<?php  echo esc_url(site_url('/เข้าสู่ระบบ'));   ?>" class="btn button-content-01">
                    <div class="button-dark"><?php echo esc_html('เข้าสู่ระบบ');?></div>
                </a>
                <a href="<?php  echo esc_url(site_url('/สมัครสมาชิก'));   ?>" class="btn button-content-01">
                    <div class="button-purple"><?php echo esc_html('สมัครสมาชิก');?></div>
                </a>
            </div>
        </div>
    </div>
    <!-- End Navbar -->

    <div class="d-flex flex-row">
        <!-- Side Bar -->
        <div class="sidebar-menu">
            <div class="tab-game-menu">
                <ul class="tab-menu-left">
                    <li class="tab-menu-left-item">
                        <a href="<?php  echo esc_url(site_url('/ยอดนิยม'));   ?>" class="nav-link menu-item-list py-2">
                            <img src="<?php echo get_theme_file_uri('/public/img/icon/ic-nav-menu-hot-game.png');?>" class="img-fluid me-2" width="50"
                                alt="icon-menu">
                                <?php echo esc_html('ยอดนิยม');?>
                        </a>
                    </li>
                    <li class="tab-menu-left-item active">
                        <a href="<?php  echo esc_url(site_url('/สล็อตเกม'));   ?>" class="nav-link menu-item-list py-2">
                            <img src="<?php echo get_theme_file_uri('/public/img/icon/EZ-Casino-บริการสล็อตออนไลน์-ฝาก-100-รับเครดิตฟรี-100.png');?>"
                                class="img-fluid me-2" width="50" alt="icon-menu">
                                <?php echo esc_html('สล็อตเกม');?>
                        </a>
                    </li>
                    <li class="tab-menu-left-item">
                        <a href="<?php  echo esc_url(site_url('/คาสิโนสด'));   ?>" class="nav-link menu-item-list py-2">
                            <img src="<?php echo get_theme_file_uri('/public/img/icon/EZ-Casino-คาสิโนออนไลน์-บาคาร่าสด-รูเล็ต-ซิคโบ-ไฮโล-เสือ-มังกร.png');?>"
                                class="img-fluid me-2" width="50" alt="icon-menu">
                                <?php echo esc_html('คาสิโนสด');?>
                        </a>
                    </li>
                    <li class="tab-menu-left-item">
                        <a href="<?php  echo esc_url(site_url('/กีฬา'));   ?>" class="nav-link menu-item-list py-2">
                            <img src="<?php echo get_theme_file_uri('/public/img/icon/EZ-Casino-แทงฟุตบอลพนันออนไลน์-บาสเก็ตบอล-E-Sport.png');?>"
                                class="img-fluid me-2" width="50" alt="icon-menu">
                                <?php echo esc_html('กีฬา');?>
                        </a>
                    </li>
                    <li class="tab-menu-left-item">
                        <a href="<?php  echo esc_url(site_url('/หวย'));   ?>" class="nav-link menu-item-list py-2">
                            <img src="<?php echo get_theme_file_uri('/public/img/icon/04-1.png');?>" class="img-fluid me-2" width="50" alt="icon-menu">
                            <?php echo esc_html('หวย');?>
                        </a>
                    </li>
                    <li class="tab-menu-left-item">
                        <a href="<?php  echo esc_url(site_url('/ทดลองเล่น'));   ?>" class="nav-link menu-item-list py-2">
                            <img src="<?php echo get_theme_file_uri('/public/img/icon/ic-nav-menu-e-sport.png');?>" class="img-fluid me-2" width="50"
                                alt="icon-menu">
                                <?php echo esc_html('ทดลองเล่น');?>
                        </a>
                    </li>
                </ul>
            </div>

            <div class="position-absolute bottom-0 start-50 translate-middle">
                <img src="<?php echo get_theme_file_uri('/public/img/linetext.png');?>" width="150" alt="img">
            </div>
        </div>
        <!-- End Side Bar -->
