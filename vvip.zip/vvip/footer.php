<!-- Line Contect Mobile -->
<div class="line-contact">
        <a href="#" class="nav-link">
            <img src="<?php echo get_theme_file_uri('/public/img/icon/lineright2.png');?>" class="img-fluid" width="100" height="125" alt="img">
        </a>
    </div>
    <!-- End Line Contect Mobile -->


    <!-- Menu Footer Mobile -->
    <div class="menu-footer">
        <div class="d-flex flex-row">
            <div class="menu-footer-list">
                <a href="<?php  echo esc_url(site_url('/เข้าสู่ระบบ'));   ?>" class="nav-link text-center">
                    <img src="<?php echo get_theme_file_uri('/public/img/icon/ic-menu-login-animate-1.png');?>" class="img-fluid" width="34" height="54"
                        alt="icon-menu">
                    <div class="text-center fs-7"><?php echo esc_html('เข้าสู่ระบบ');?></div>
                </a>
            </div>
            <div class="menu-footer-list">
                <a href="<?php  echo esc_url(site_url('/สมัคร'));   ?>" class="nav-link text-center">
                    <img src="<?php echo get_theme_file_uri('/public/img/icon/ic-menu-register.png" class="img-fluid');?>" width="34" height="54" alt="icon-menu">
                    <div class="text-center fs-7"><?php echo esc_html('สมัคร');?></div>
                </a>
            </div>
            <div class="menu-footer-list">
                <a href="<?php  echo esc_url(site_url('/กิจกรรม'));   ?>" class="nav-link text-center">
                    <img src="<?php echo get_theme_file_uri('/public/img/icon/menu.png" class="img-fluid');?>" width="34" height="54" alt="icon-menu">
                    <div class="text-center fs-7"><?php echo esc_html('กิจกรรม');?></div>
                </a>
            </div>
            <div class="menu-footer-list">
                <a href="<?php  echo esc_url(site_url('/โปรโมชั่น'));   ?>" class="nav-link text-center">
                    <img src="<?php echo get_theme_file_uri('/public/img/icon/tab_promotion-1.png');?>" class="img-fluid" width="34" height="54" alt="icon-menu">
                    <div class="text-center fs-7"><?php echo esc_html('โปรโมชั่น'); ?></div>
                </a>
            </div>
            <div class="menu-footer-list">
                <a href="<?php  echo esc_url(site_url('/ติดต่อเรา'));   ?>" class="nav-link text-center">
                    <img src="<?php echo get_theme_file_uri('/public/img/icon/support.png');?>" class="img-fluid" width="34" height="54" alt="icon-menu">
                    <div class="text-center fs-7"><?php echo esc_html('ติดต่อเรา') ?></div>
                </a>
            </div>
        </div>
    </div>
    <!-- End Menu Footer Mobile -->


    <!-- Bootstrap JavaScript Libraries -->
  
   <?php  wp_footer(); ?>
</body>

</html>