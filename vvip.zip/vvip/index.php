<?php  get_header();  ?>
        <!-- Content -->
        <div class="content-games-master">
            <div class="container-fluid">
                <div class="row g-2">
                    <div class="col-6"><img src="./img/linetext.png" class="img-fluid" alt="" srcset=""></div>
                    <div class="col-6"><img src="./img/linetext.png" class="img-fluid" alt="" srcset=""></div>
                </div>
                <h1 class="text-white">Content</h1>
            </div>

        </div>
        <!-- End Content -->

    </div>
<?php  get_footer();  ?>

    