<?php

function add_scriptions_lap(){

    wp_enqueue_style('vvip-style' , get_stylesheet_uri() , array() , '1.0');
    wp_enqueue_style('vvip-style-theme' , get_theme_file_uri('/public/css/style.css') , array() , '1.0');
    wp_enqueue_style('vvip-font-theme' , '//fonts.googleapis.com/css2?family=Kanit:wght@100;200;300;400;500;600;700;800;900&display=swap', array() , '1.0');
    wp_enqueue_style('vvip-bootstrap-theme' , '//cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css', array() , '1.0');
    wp_enqueue_style('vvip-bootstrap-icon' , '//cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css', array() , '1.0');

    wp_enqueue_script('app-lab-popper' , '//cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js' , array() , '1.0.0' , true);
    wp_enqueue_script('app-lab-boot' , '//cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js', array() , '1.0.0' , true);
    
}

add_action('wp_enqueue_scripts','add_scriptions_lap');

