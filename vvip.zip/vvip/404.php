<?php  get_header();  ?>
        <!-- Content -->
        <div class="content-games-master">
            <div class="container-fluid">
                <div class="row g-2">
                    <div class="col-6"><img src="./img/linetext.png" class="img-fluid" alt="" srcset=""></div>
                    <div class="col-6"><img src="./img/linetext.png" class="img-fluid" alt="" srcset=""></div>
                </div>
                <div class="container">
                        <h1 class="text-white mt-3" style="text-align:center;">404 NOT FOUND</h1>
                        <h3 class="text-white mt-3" style="text-align:center;">ไม่พบหน้าที่คุณต้องการ</h3>

                </div>
              
               
            </div>

        </div>
        <!-- End Content -->

    </div>
<?php  get_footer();  ?>

    