<a class="qiupid-back-to-top qiupid-is-visible qiupid-fade-out" href="<?php echo esc_url('#0'); ?>">
    <i class="fas fa-angle-up"></i>
</a>