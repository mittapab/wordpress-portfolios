<div class="article-detail-meta post-date">
    <i class="far fa-calendar-alt"></i>
    <?php echo esc_html(get_the_date()); ?>
</div>