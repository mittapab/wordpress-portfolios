<div class="qiupid-post-metas">
    <div class="qiupid-article-details">
        <?php get_template_part('templates/content/templates/sections/list/post-author' ); ?>
        <?php get_template_part('templates/content/templates/sections/list/post-category' ); ?>
        <?php get_template_part('templates/content/templates/sections/list/post-date' ); ?>
    </div>
</div>