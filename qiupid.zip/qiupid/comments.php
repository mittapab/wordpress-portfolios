<?php
/**
 * Get comments template
 *
 * @package qiupid
 */

get_template_part('templates/comments/templates/comments');