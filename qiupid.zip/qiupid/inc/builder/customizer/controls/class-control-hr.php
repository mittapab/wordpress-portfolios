<?php
class Qiupid_Customizer_Control_Hr extends Qiupid_Customizer_Control_Base {
	static function field_template() {
		?>
		<script type="text/html" id="tmpl-field-qiupid-hr">
		<?php
		echo '<hr/>';
		?>
		</script>
		<?php
	}
}
